<h3 align="center">MetricImperialConverter</h3>

<h3 align="left">Project Guidelines</h3>
<ol style="align:left">
<li>Restore the Nuget packages</li>
<li>After running project it will land to swagger url</li>
<li><p>There will be one post method ConvertMetricImperialUnit, expanding that under body params it will ask for user input. Userinput will be SourceType: cm,inch or DegreeCelsius etc any one value, ConvertType will be cm,inch or DegreeCelsius any one value, 
ConversionCategory: 0 for Metric to Imperial and 1 for Imperial to Metric. InputValue will be value to be converted.
</p></li>
<li>If SourceType and ConvertType will not match with DB it will throw not found</li>
<li>If any exception arise it will throw 500 internal server error</li>
<li>If all goes well then it will return Ok status with converted value</li>
<li>For DB connection string that to be added in appsettings.json under connectionstrings</li>
<li>For DB refer DBScript file under proj zip in which table creation script and data insertion script exist.
<li> Finally you are good to use API for Metric to Imperial conversion and vice versa.
</ol>

