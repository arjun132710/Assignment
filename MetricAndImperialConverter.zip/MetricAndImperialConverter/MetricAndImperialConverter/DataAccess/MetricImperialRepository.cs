﻿using MetricAndImperialConverter.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MetricAndImperialConverter.DataAccess
{
    public class MetricImperialRepository : IMetricImperialRepository
    {
        DemoProjectContext demoProjectContext;
        public MetricImperialRepository(DemoProjectContext myContext)
        {
            demoProjectContext = myContext;
        }

        public string GetMetricImperialValue(MetricImperialData metricImperialData)
        {
            string value = string.Empty;
            if (metricImperialData.ConversionCategory == ConversionCategory.Imperial)
            {
                value = demoProjectContext.Imperials.Where(x => x.SourceType == metricImperialData.SourceType && x.ConvertType == metricImperialData.ConvertType).FirstOrDefault()?.Value;
            }
            else if (metricImperialData.ConversionCategory == ConversionCategory.Metric)
            {
                value = demoProjectContext.Metrics.Where(x => x.SourceType == metricImperialData.SourceType && x.ConvertType == metricImperialData.ConvertType).FirstOrDefault()?.Value;
            }
            return value;
        }
    }
}
