﻿using MetricAndImperialConverter.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MetricAndImperialConverter.DataAccess
{
    public interface IMetricImperialRepository
    {
        string GetMetricImperialValue(MetricImperialData metricImperialData);
    }
}
