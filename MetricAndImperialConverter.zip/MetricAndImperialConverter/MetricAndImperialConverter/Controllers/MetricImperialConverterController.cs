﻿using MetricAndImperialConverter.DataAccess;
using MetricAndImperialConverter.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MetricAndImperialConverter.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MetricImperialConverterController : ControllerBase
    {
        private IMetricImperialRepository _metricImperialRepository;
        public MetricImperialConverterController(IMetricImperialRepository metricImperialRepository)
        {
            _metricImperialRepository = metricImperialRepository;
        }

        [HttpPost]
        public IActionResult ConvertMetricImperialUnit([FromBody] MetricImperialData metricImperialData)
        {
            try
            {
                string[] splitValues = null;
                decimal outputValue = 0;
                string convertValue = _metricImperialRepository.GetMetricImperialValue(metricImperialData);
                if (!string.IsNullOrEmpty(convertValue))
                {
                    if (convertValue.Contains(','))
                    {
                        splitValues = convertValue.Split(',');
                    }
                    else
                    {
                        splitValues = new string[1] { convertValue };
                    }
                }
                else
                {
                    return NotFound();
                }

                if(metricImperialData.SourceType.ToLower() == Constant.Celsius && metricImperialData.ConvertType.ToLower() == Constant.Fahrenheit)
                {
                    outputValue = (metricImperialData.InputValue * Convert.ToDecimal(splitValues[0])) + Convert.ToDecimal(splitValues[1]);
                }
                else if(metricImperialData.SourceType.ToLower() == Constant.Fahrenheit && metricImperialData.ConvertType.ToLower() == Constant.Celsius)
                {
                    outputValue = (metricImperialData.InputValue - Convert.ToDecimal(splitValues[0])) / Convert.ToDecimal(splitValues[1]) ;
                }
                else
                {
                    outputValue = metricImperialData.InputValue * Convert.ToDecimal(splitValues[0]);
                }

                return Ok(outputValue);
            }
            catch
            {
                return StatusCode(500);
            }
        }
    }
}
