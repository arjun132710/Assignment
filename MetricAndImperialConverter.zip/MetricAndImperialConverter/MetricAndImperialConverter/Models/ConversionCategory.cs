﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MetricAndImperialConverter.Models
{
    public enum ConversionCategory
    {
        Metric,
        Imperial
    }

    public class MetricImperialData
    {
        public string SourceType { get; set; }
        public string ConvertType { get; set; }
        public decimal InputValue { get; set; }
        public ConversionCategory ConversionCategory { get; set; }
    }

    public static class Constant
    {
        public static string Celsius = "celsius";
        public static string Fahrenheit = "fahrenheit";
    }
}
