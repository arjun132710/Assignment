﻿using System;
using System.Collections.Generic;

#nullable disable

namespace MetricAndImperialConverter.Models
{
    public partial class Imperial
    {
        public int ImperialId { get; set; }
        public string SourceType { get; set; }
        public string ConvertType { get; set; }
        public string Value { get; set; }
    }
}
