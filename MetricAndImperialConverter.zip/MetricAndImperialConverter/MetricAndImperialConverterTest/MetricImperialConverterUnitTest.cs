using MetricAndImperialConverter.Controllers;
using MetricAndImperialConverter.DataAccess;
using MetricAndImperialConverter.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;

namespace MetricAndImperialConverterTest
{
    [TestClass]
    public class MetricImperialConverterUnitTest
    {
        [TestMethod]
        public void ConvertMetricImperialUnit_WhenConvertInchestocm_ReturnConvertedCmvalue()
        {
            // Arrange
            MetricImperialData metricImperialData = new MetricImperialData();
            metricImperialData.SourceType = "inches";
            metricImperialData.ConvertType = "cm";
            metricImperialData.ConversionCategory = ConversionCategory.Imperial;
            metricImperialData.InputValue = 100;
            decimal expectedOutputValue = 254M;

            var mockRepo = new Mock<IMetricImperialRepository>();
            mockRepo.Setup(x => x.GetMetricImperialValue(metricImperialData)).Returns("2.54");
            var metricImperialObject = new MetricImperialConverterController(mockRepo.Object);

            // Act
            var outputData = metricImperialObject.ConvertMetricImperialUnit(metricImperialData);

            // Assert
            var okObjectResult = outputData as OkObjectResult;
            Assert.IsNotNull(okObjectResult);
            var outputvalue =  okObjectResult.Value as decimal?;
            Assert.IsNotNull(outputvalue);
            Assert.AreEqual(outputvalue, expectedOutputValue);
        }

        [TestMethod]
        public void ConvertMetricImperialUnit_WhenConvertCelsiustoFahrenheit_ReturnConvertedFahrenheitvalue()
        {
            // Arrange
            MetricImperialData metricImperialData = new MetricImperialData();
            metricImperialData.SourceType = "Celsius";
            metricImperialData.ConvertType = "Fahrenheit";
            metricImperialData.ConversionCategory = ConversionCategory.Metric;
            metricImperialData.InputValue = 37;
            decimal expectedOutputValue = 98.6M;

            var mockRepo = new Mock<IMetricImperialRepository>();
            mockRepo.Setup(x => x.GetMetricImperialValue(metricImperialData)).Returns("1.8,32");
            var metricImperialObject = new MetricImperialConverterController(mockRepo.Object);

            // Act
            var outputData = metricImperialObject.ConvertMetricImperialUnit(metricImperialData);

            // Assert
            var okObjectResult = outputData as OkObjectResult;
            Assert.IsNotNull(okObjectResult);
            var outputvalue = okObjectResult.Value as decimal?;
            Assert.IsNotNull(outputvalue);
            Assert.AreEqual(outputvalue, expectedOutputValue);
        }

        [TestMethod]
        public void ConvertMetricImperialUnit_WhenConvertFahrenheitToCelsius_ReturnConvertedCelsiusvalue()
        {
            // Arrange
            MetricImperialData metricImperialData = new MetricImperialData();
            metricImperialData.SourceType = "Fahrenheit";
            metricImperialData.ConvertType = "Celsius";
            metricImperialData.ConversionCategory = ConversionCategory.Imperial;
            metricImperialData.InputValue = 98.6M;
            decimal expectedOutputValue = 37M;

            var mockRepo = new Mock<IMetricImperialRepository>();
            mockRepo.Setup(x => x.GetMetricImperialValue(metricImperialData)).Returns("32,1.8");
            var metricImperialObject = new MetricImperialConverterController(mockRepo.Object);

            // Act
            var outputData = metricImperialObject.ConvertMetricImperialUnit(metricImperialData);

            // Assert
            var okObjectResult = outputData as OkObjectResult;
            Assert.IsNotNull(okObjectResult);
            var outputvalue = okObjectResult.Value as decimal?;
            Assert.IsNotNull(outputvalue);
            Assert.AreEqual(outputvalue, expectedOutputValue);
        }

    }
}
